package com.cookingassist.demo.service;

import com.cookingassist.demo.repository.RecipeRepository;
import com.cookingassist.demo.model.Recipe;
import com.cookingassist.demo.model.RecipeId;
import com.cookingassist.demo.util.ErrorRecipe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RecipeService {

        private long recipeid = 1L;
        @Autowired
        private RecipeRepository recipeRepository;

        public List<Recipe> getAll(){
            Iterable<Recipe> recipes=recipeRepository.findAll();
            List<Recipe> recipeList=new ArrayList<>();
            recipes.forEach(recipeList::add);
            return recipeList;
        }

        public Object insert(Recipe recipe){
            RecipeId recipeIds = new RecipeId(recipe.getName(),recipe.getRecipeStepNumber());
            if(!recipeRepository.existsById(recipeIds)) {
//                recipeid++;
//                recipe.setId(recipeid);

               return recipeRepository.save(recipe);
            }
            return new ErrorRecipe("Use update for this");
        }

        public Object update(Recipe recipe){

            RecipeId recipeIds = new RecipeId(recipe.getName(),recipe.getRecipeStepNumber());
            if(recipeRepository.existsById(recipeIds)) {

                return recipeRepository.save(recipe);
            }
            return new ErrorRecipe("Use update for this");
        }

        public void delete(RecipeId id){
            recipeRepository.deleteById(id);
        }
        public List<String> getAllRecipeNames(){
            return recipeRepository.getRecipeNames();
        }
        public List<Recipe> getRecipeByName(String name){
            return recipeRepository.getRecipeByName(name);
        }
    public List<String> getRecipeProcedure(String name){
        return recipeRepository.getRecipeProcedure(name);
    }

    }


