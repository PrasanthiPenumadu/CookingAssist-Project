package com.cookingassist.demo.model;

import java.util.ArrayList;
import java.util.List;

public class RecipeProcedure {
    String name;
    String Ingredients;
    Integer cookTime;
    String recipeImage;
    List<String> recipeSteps=new ArrayList<>();

    public RecipeProcedure(String name, String ingredients, Integer cookTime, String recipeImage, List<String> recipeSteps) {
        this.name = name;
        Ingredients = ingredients;
        this.cookTime = cookTime;
        this.recipeImage = recipeImage;
        this.recipeSteps = recipeSteps;
    }
}
