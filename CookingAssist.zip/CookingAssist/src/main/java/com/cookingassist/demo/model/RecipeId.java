package com.cookingassist.demo.model;

import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@NoArgsConstructor
public class RecipeId implements Serializable {


    private String name;

    private Integer recipeStepNumber;

    public RecipeId(String name, Integer recipeStepNumber){

        this.name=name;
        this.recipeStepNumber=recipeStepNumber;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RecipeId recipeId = (RecipeId) o;
        return name.equals(recipeId.name) &&
                recipeStepNumber.equals(recipeId.recipeStepNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, recipeStepNumber);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRecipeStepNumber() {
        return recipeStepNumber;
    }

    public void setRecipeStepNumber(Integer recipeStepNumber) {
        this.recipeStepNumber = recipeStepNumber;
    }
}
