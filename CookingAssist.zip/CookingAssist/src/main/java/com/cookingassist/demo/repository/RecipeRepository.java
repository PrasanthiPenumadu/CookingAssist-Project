package com.cookingassist.demo.repository;

import com.cookingassist.demo.model.Recipe;
import com.cookingassist.demo.model.RecipeId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RecipeRepository extends CrudRepository<Recipe, RecipeId> {

    @Query("select distinct recipeTable.name from Recipe recipeTable ")
    List<String> getRecipeNames();

    @Query("select recipeTable from Recipe recipeTable where recipeTable.name=?1")
    List<Recipe> getRecipeByName(String name);

    @Query("select recipeTable.recipeStepProcedure from Recipe recipeTable where recipeTable.name=?1")
    List<String> getRecipeProcedure(String name);

//    @Query("select recipeTable from Recipe recipeTable where recipeTable.name=?1 recipeTable.recipeStepNumber=?1")

    @Query("select distinct recipeTable.name,recipeTable.cookTime,recipeTable.ingredients from Recipe recipeTable where recipeTable.name=?1")
    List<Object> getRecipeHeader(String name);
}

//count time
//header
//procedure