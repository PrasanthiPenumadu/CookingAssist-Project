package com.cookingassist.demo.util;

public class ErrorRecipe {

    private String errormessage;

    public ErrorRecipe(String errormessage) {
        this.errormessage = errormessage;
    }

    public String getErrormessage() {
        return errormessage;
    }

    public void setErrormessage(String errormessage) {
        this.errormessage = errormessage;
    }
}
