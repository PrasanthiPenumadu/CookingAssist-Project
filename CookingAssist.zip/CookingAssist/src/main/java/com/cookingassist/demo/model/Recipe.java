package com.cookingassist.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@IdClass(RecipeId.class)

public class Recipe implements Serializable{

//
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    private Long id =1l;

    public String getName() {
        return name;
    }

    public Integer getRecipeStepNumber() {
        return recipeStepNumber;
    }

//    public void setId(Long id) {
//        this.id = id;
//    }

    @Column(name = "name")
    @NotEmpty
    @Id
    @NotNull
    private String name;
    @Column(name = "recipeStepNumber")
    @NotNull
    @Id
    private Integer recipeStepNumber;
    @Column(name = "recipeStepProcedure")
    @NotBlank
    private String recipeStepProcedure;
    @Column
    @NotNull
    private Integer cookTime;
    @Column
    @NotBlank
    private String ingredients;
    @Column
    private String recipeImage;
    @Column(insertable = true, updatable = false)
    private LocalDateTime created;
    @Column
    private LocalDateTime updated;

    public Recipe(String name, Integer recipeStepNumber,String recipeStepProcedure,Integer cookTime, String ingredients){

        this.name=name;
        this.recipeStepNumber=recipeStepNumber;
        this.ingredients=ingredients;
        this.recipeStepProcedure=recipeStepProcedure;
        this.cookTime=cookTime;

    }
    @PrePersist
    void onCreate(){
        this.created=LocalDateTime.now();
//        this.id=id++;
    }
    @PreUpdate
    void onUpdate(){
        this.updated = LocalDateTime.now();
    }
}