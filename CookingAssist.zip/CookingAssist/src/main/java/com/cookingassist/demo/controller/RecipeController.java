package com.cookingassist.demo.controller;

import com.cookingassist.demo.model.Recipe;
import com.cookingassist.demo.model.RecipeId;
import com.cookingassist.demo.repository.RecipeRepository;
import com.cookingassist.demo.service.RecipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;

import javax.validation.Valid;
import java.util.List;
@RestController
@RequestMapping
@Component
public class RecipeController {

    @Autowired
    RecipeService recipeService;

    @Autowired
    RecipeRepository recipeRepository;

    @GetMapping("/recipes")
    public List<Recipe> getAll(){
        return recipeService.getAll();
    }
    @GetMapping("/recipes/{name}")
    public List<Recipe> getRecipeByName(@PathVariable String name){
        return recipeService.getRecipeByName(name);
    }
    @GetMapping("/recipesProcedure/{name}")
    public List<String> getRecipeProcedure(@PathVariable String name){
        return recipeService.getRecipeProcedure(name);
    }
    @GetMapping("/recipes/list")
    public List<String> getRecipeNames(){
        return recipeService.getAllRecipeNames();
    }

    @PostMapping(value = "/recipes")//, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Object> insert(@RequestBody Recipe recipe){
        Object returnrecipe = recipeService.insert(recipe);
        if (returnrecipe instanceof Recipe)return new ResponseEntity(returnrecipe, HttpStatus.OK);
        else return new ResponseEntity(returnrecipe, HttpStatus.BAD_REQUEST);
    }

    @PutMapping("/recipes")
    public  ResponseEntity<Object> update(@RequestBody Recipe recipe){
       Object updaterecipe= recipeService.update(recipe);
        if (updaterecipe instanceof Recipe)return new ResponseEntity(updaterecipe, HttpStatus.OK);
        else return new ResponseEntity(updaterecipe, HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping("/recipes")
    public ResponseEntity<Recipe> delete(@Valid @RequestBody RecipeId id, Errors errors){
        if (errors.hasErrors()) return new ResponseEntity(id, HttpStatus.BAD_REQUEST);
        recipeService.delete(id);
        return new ResponseEntity( HttpStatus.OK);
    }

}
