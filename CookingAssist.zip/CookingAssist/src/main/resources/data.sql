insert into Recipe (name,recipe_step_number,recipe_step_procedure,cook_time,
ingredients)values ( 'MangoShake','1' ,'Gather the Ingredients','10','Mango pulp,Milk,Sugar,whipped cream' );
insert into Recipe (name,recipe_step_number,recipe_step_procedure,cook_time,
                    ingredients)values ( 'AppleShake','1' ,'Gather the Ingredients','10','apple,Milk,Sugar,whipped cream' );
insert into Recipe (name,recipe_step_number,recipe_step_procedure,cook_time,
                    ingredients)values ( 'MangoYogurt','1' ,'Gather the Ingredients','10','Mango pulp,yogurt,Sugar,whipped cream' );